const databaseCredentials = 'mongodb+srv://Tadeja:09feriferi@cluster0.v9r0w.mongodb.net/ludogame?retryWrites=true&w=majority'
const jwtSign = "8924ktn4l5b3mjg3jk";
module.exports = { databaseCredentials, jwtSign };